# distance-between-two-place-php
Find the distance between two places using Google map Api in PHP
This is a PHP code.
You just have to enter GOOGLE MAP API KEY
AND Just run your php code.
